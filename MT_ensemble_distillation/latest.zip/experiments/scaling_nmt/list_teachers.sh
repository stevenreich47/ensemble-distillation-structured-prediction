#! /usr/bin/env bash

ls -l -h /expscratch/nandrews/nmt/fairseq/jobs/teachers
df -h /expscratch/nandrews/nmt/fairseq/jobs/teachers

# eof
