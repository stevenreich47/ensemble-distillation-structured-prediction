#! /usr/bin/env bash

echo "/expscratch/nandrews/nmt/fairseq/jobs/de2en/teachers"
ls -l -h /expscratch/nandrews/nmt/fairseq/jobs/de2en/teachers
df -h /expscratch/nandrews/nmt/fairseq/jobs/de2en/teachers

# eof
